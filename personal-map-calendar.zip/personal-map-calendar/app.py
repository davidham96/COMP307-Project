from flask import Flask, render_template, request, jsonify, flash, redirect, url_for, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import os
import json
from flask_migrate import Migrate
from functools import wraps

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
migrate = Migrate(app, db)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    map_settings = db.Column(db.JSON, default={})
    calendar_settings = db.Column(db.JSON, default={})
    events = db.relationship('Event', backref='user', lazy=True)
    locations = db.relationship('Location', backref='user', lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    start = db.Column(db.DateTime, nullable=False)
    end = db.Column(db.DateTime, nullable=False)
    description = db.Column(db.Text)
    location = db.Column(db.String(200))
    color = db.Column(db.String(20))
    is_public = db.Column(db.Boolean, default=False)
    is_recurring = db.Column(db.Boolean, default=False)
    schedule_id = db.Column(db.Integer, db.ForeignKey('schedule.id'), nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

class Schedule(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    frequency = db.Column(db.String(20), nullable=False)  # daily, weekly, monthly
    days = db.Column(db.String(50))  # comma-separated days for weekly (e.g., "MON,WED,FRI")
    start_date = db.Column(db.DateTime, nullable=False)
    end_date = db.Column(db.DateTime)  # null means no end date
    time_start = db.Column(db.Time, nullable=False)
    time_end = db.Column(db.Time, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    events = db.relationship('Event', backref='schedule', lazy=True)

class LocationType(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    icon = db.Column(db.String(50), nullable=False)  # Font Awesome icon name
    description = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Location(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    type = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text)
    lat = db.Column(db.Float, nullable=False)
    lng = db.Column(db.Float, nullable=False)
    is_public = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Admin required decorator
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            abort(403)
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()
        
        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for('dashboard'))
        
        flash('Invalid email or password')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        if User.query.filter_by(email=email).first():
            flash('Email already registered')
            return redirect(url_for('register'))
        
        user = User(email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! Please login.')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/api/events', methods=['GET', 'POST'])
@login_required
def handle_events():
    if request.method == 'GET':
        events = Event.query.filter_by(user_id=current_user.id).all()
        return jsonify([{
            'id': event.id,
            'title': event.title,
            'start': event.start.isoformat(),
            'end': event.end.isoformat(),
            'description': event.description,
            'location': event.location
        } for event in events])
    
    if request.method == 'POST':
        data = request.json
        event = Event(
            title=data['title'],
            start=datetime.fromisoformat(data['start']),
            end=datetime.fromisoformat(data['end']),
            description=data.get('description', ''),
            location=data.get('location'),
            user_id=current_user.id
        )
        db.session.add(event)
        db.session.commit()
        return jsonify({'status': 'success', 'id': event.id})

@app.route('/api/events/<int:event_id>', methods=['PUT', 'DELETE'])
@login_required
def handle_event(event_id):
    event = Event.query.get_or_404(event_id)
    if event.user_id != current_user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    
    if request.method == 'PUT':
        data = request.json
        event.title = data.get('title', event.title)
        event.start = datetime.fromisoformat(data['start']) if 'start' in data else event.start
        event.end = datetime.fromisoformat(data['end']) if 'end' in data else event.end
        event.description = data.get('description', event.description)
        event.location = data.get('location', event.location)
        db.session.commit()
        return jsonify({'status': 'success'})
    
    if request.method == 'DELETE':
        db.session.delete(event)
        db.session.commit()
        return jsonify({'status': 'success'})

@app.route('/api/settings', methods=['GET', 'PUT'])
@login_required
def handle_settings():
    if request.method == 'GET':
        return jsonify({
            'map': current_user.map_settings,
            'calendar': current_user.calendar_settings
        })
    
    if request.method == 'PUT':
        data = request.json
        if 'map' in data:
            current_user.map_settings = data['map']
        if 'calendar' in data:
            current_user.calendar_settings = data['calendar']
        db.session.commit()
        return jsonify({'status': 'success'})

@app.route('/api/locations', methods=['GET', 'POST'])
@login_required
def handle_locations():
    if request.method == 'GET':
        locations = Location.query.filter_by(user_id=current_user.id).all()
        return jsonify([{
            'id': loc.id,
            'title': loc.title,
            'type': loc.type,
            'description': loc.description,
            'lat': loc.lat,
            'lng': loc.lng,
            'created_at': loc.created_at.isoformat()
        } for loc in locations])
    
    if request.method == 'POST':
        data = request.json
        location = Location(
            title=data['title'],
            type=data['type'],
            description=data.get('description', ''),
            lat=data['lat'],
            lng=data['lng'],
            user_id=current_user.id
        )
        db.session.add(location)
        db.session.commit()
        return jsonify({
            'id': location.id,
            'status': 'success'
        })

@app.route('/api/locations/<int:location_id>', methods=['PUT', 'DELETE'])
@login_required
def handle_location(location_id):
    location = Location.query.get_or_404(location_id)
    if location.user_id != current_user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    
    if request.method == 'PUT':
        data = request.json
        location.title = data.get('title', location.title)
        location.type = data.get('type', location.type)
        location.description = data.get('description', location.description)
        location.lat = data.get('lat', location.lat)
        location.lng = data.get('lng', location.lng)
        db.session.commit()
        return jsonify({'status': 'success'})
    
    if request.method == 'DELETE':
        db.session.delete(location)
        db.session.commit()
        return jsonify({'status': 'success'})

@app.route('/events', methods=['GET'])
@login_required
def get_events():
    start = request.args.get('start')
    end = request.args.get('end')
    
    start_date = datetime.fromisoformat(start.replace('Z', '+00:00'))
    end_date = datetime.fromisoformat(end.replace('Z', '+00:00'))
    
    events = Event.query.filter(
        (Event.start >= start_date) & (Event.end <= end_date) &
        ((Event.is_public == True) | (Event.user_id == current_user.id))
    ).all()
    
    return jsonify([{
        'id': event.id,
        'title': event.title,
        'start': event.start.isoformat(),
        'end': event.end.isoformat(),
        'description': event.description,
        'is_public': event.is_public,
        'color': event.color
    } for event in events])

@app.route('/events', methods=['POST'])
@login_required
def create_event():
    data = request.json
    
    start = datetime.fromisoformat(data['start'].replace('Z', '+00:00'))
    end = datetime.fromisoformat(data['end'].replace('Z', '+00:00'))
    
    event = Event(
        title=data['title'],
        start=start,
        end=end,
        description=data.get('description', ''),
        is_public=data.get('is_public', False),
        user_id=current_user.id,
        color=data.get('color', '#3788d8')
    )
    
    db.session.add(event)
    db.session.commit()
    
    return jsonify({
        'id': event.id,
        'title': event.title,
        'start': event.start.isoformat(),
        'end': event.end.isoformat(),
        'description': event.description,
        'is_public': event.is_public,
        'color': event.color
    })

@app.route('/events/<int:event_id>', methods=['PUT', 'DELETE'])
@login_required
def manage_event(event_id):
    event = Event.query.get_or_404(event_id)
    
    if event.user_id != current_user.id:
        abort(403)
    
    if request.method == 'DELETE':
        db.session.delete(event)
        db.session.commit()
        return '', 204
    
    data = request.json
    event.title = data['title']
    event.start = datetime.fromisoformat(data['start'].replace('Z', '+00:00'))
    event.end = datetime.fromisoformat(data['end'].replace('Z', '+00:00'))
    event.description = data.get('description', '')
    event.is_public = data.get('is_public', False)
    event.color = data.get('color', '#3788d8')
    
    db.session.commit()
    
    return jsonify({
        'id': event.id,
        'title': event.title,
        'start': event.start.isoformat(),
        'end': event.end.isoformat(),
        'description': event.description,
        'is_public': event.is_public,
        'color': event.color
    })

@app.route('/admin')
@login_required
@admin_required
def admin_dashboard():
    return render_template('admin.html', google_maps_api_key=os.environ.get('GOOGLE_MAPS_API_KEY', ''))

@app.route('/admin/locations', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_locations():
    if request.method == 'POST':
        data = request.get_json()
        location = Location(
            title=data['title'],
            type=data['type'],
            description=data.get('description', ''),
            lat=data['lat'],
            lng=data['lng'],
            is_public=True,
            user_id=current_user.id
        )
        db.session.add(location)
        db.session.commit()
        return jsonify({'status': 'success', 'id': location.id})
    
    public_locations = Location.query.filter_by(is_public=True).all()
    return jsonify([{
        'id': loc.id,
        'title': loc.title,
        'type': loc.type,
        'description': loc.description,
        'lat': loc.lat,
        'lng': loc.lng,
        'created_at': loc.created_at.isoformat()
    } for loc in public_locations])

@app.route('/admin/locations/<int:location_id>', methods=['GET', 'PUT', 'DELETE'])
@login_required
@admin_required
def admin_location(location_id):
    location = Location.query.get_or_404(location_id)
    
    if request.method == 'GET':
        return jsonify({
            'id': location.id,
            'title': location.title,
            'type': location.type,
            'description': location.description or '',
            'lat': location.lat,
            'lng': location.lng,
            'created_at': location.created_at.isoformat() if location.created_at else None
        })
    
    if request.method == 'DELETE':
        db.session.delete(location)
        db.session.commit()
        return jsonify({'status': 'success'})
    
    data = request.get_json()
    location.title = data['title']
    location.type = data['type']
    location.description = data.get('description', '')
    location.lat = data['lat']
    location.lng = data['lng']
    db.session.commit()
    return jsonify({'status': 'success'})

@app.route('/admin/location-types', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_location_types():
    if request.method == 'POST':
        try:
            data = request.get_json()
            if not data:
                return jsonify({'error': 'No data provided'}), 400
            
            if not data.get('name'):
                return jsonify({'error': 'Name is required'}), 400
            
            if not data.get('icon'):
                return jsonify({'error': 'Icon is required'}), 400
            
            # Clean the icon name
            icon = data['icon'].strip()
            if not icon.startswith('fa-'):
                icon = f'fa-{icon}'
            
            location_type = LocationType(
                name=data['name'].strip(),
                icon=icon,
                description=data.get('description', '').strip()
            )
            db.session.add(location_type)
            db.session.commit()
            return jsonify({
                'status': 'success',
                'id': location_type.id,
                'message': 'Location type created successfully'
            })
        except Exception as e:
            db.session.rollback()
            print(f"Error creating location type: {str(e)}")  # For debugging
            return jsonify({
                'error': 'Failed to create location type',
                'details': str(e)
            }), 500
    
    try:
        types = LocationType.query.all()
        return jsonify([{
            'id': t.id,
            'name': t.name,
            'icon': t.icon,
            'description': t.description,
            'created_at': t.created_at.isoformat() if t.created_at else None
        } for t in types])
    except Exception as e:
        print(f"Error fetching location types: {str(e)}")  # For debugging
        return jsonify({
            'error': 'Failed to fetch location types',
            'details': str(e)
        }), 500

@app.route('/admin/location-types/<int:type_id>', methods=['GET', 'PUT', 'DELETE'])
@login_required
@admin_required
def admin_location_type(type_id):
    try:
        location_type = LocationType.query.get_or_404(type_id)
        
        if request.method == 'GET':
            return jsonify({
                'id': location_type.id,
                'name': location_type.name,
                'icon': location_type.icon,
                'description': location_type.description,
                'created_at': location_type.created_at.isoformat() if location_type.created_at else None
            })
        
        if request.method == 'DELETE':
            db.session.delete(location_type)
            db.session.commit()
            return jsonify({
                'status': 'success',
                'message': 'Location type deleted successfully'
            })
        
        # PUT method
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        if 'name' in data:
            location_type.name = data['name'].strip()
        if 'icon' in data:
            icon = data['icon'].strip()
            if not icon.startswith('fa-'):
                icon = f'fa-{icon}'
            location_type.icon = icon
        if 'description' in data:
            location_type.description = data.get('description', '').strip()
        
        db.session.commit()
        return jsonify({
            'status': 'success',
            'message': 'Location type updated successfully'
        })
        
    except Exception as e:
        db.session.rollback()
        print(f"Error managing location type: {str(e)}")  # For debugging
        return jsonify({
            'error': 'Failed to manage location type',
            'details': str(e)
        }), 500

@app.route('/public/locations')
def public_locations():
    locations = Location.query.filter_by(is_public=True).all()
    return jsonify([{
        'id': loc.id,
        'title': loc.title,
        'type': loc.type,
        'description': loc.description,
        'lat': loc.lat,
        'lng': loc.lng
    } for loc in locations])

@app.route('/events/schedule', methods=['POST'])
@login_required
def create_schedule():
    data = request.get_json()
    
    # Create schedule
    schedule = Schedule(
        frequency=data['frequency'],
        days=','.join(data.get('days', [])),
        start_date=datetime.fromisoformat(data['startDate']),
        time_start=datetime.strptime(data['timeStart'], '%H:%M').time(),
        time_end=datetime.strptime(data['timeEnd'], '%H:%M').time()
    )
    
    if 'endDate' in data:
        schedule.end_date = datetime.fromisoformat(data['endDate'])
    
    db.session.add(schedule)
    
    # Create recurring events
    events = []
    current_date = schedule.start_date
    end_date = schedule.end_date or (current_date + timedelta(days=365))  # Default to 1 year if no end date
    
    while current_date <= end_date:
        if schedule.frequency == 'daily' or (
            schedule.frequency == 'weekly' and 
            current_date.strftime('%a').upper() in schedule.days.split(',')
        ):
            event = Event(
                title=data['title'],
                start=datetime.combine(current_date.date(), schedule.time_start),
                end=datetime.combine(current_date.date(), schedule.time_end),
                description=data.get('description', ''),
                location=data.get('location', ''),
                color=data.get('color', '#3788d8'),
                is_recurring=True,
                schedule=schedule,
                user_id=current_user.id
            )
            events.append(event)
        
        current_date += timedelta(days=1)
    
    db.session.add_all(events)
    db.session.commit()
    
    return jsonify({
        'status': 'success',
        'message': 'Schedule created successfully',
        'scheduleId': schedule.id
    })

@app.route('/events/schedule/<int:schedule_id>', methods=['PUT', 'DELETE'])
@login_required
def manage_schedule(schedule_id):
    schedule = Schedule.query.get_or_404(schedule_id)
    events = Event.query.filter_by(schedule_id=schedule_id, user_id=current_user.id).all()
    
    if request.method == 'DELETE':
        for event in events:
            db.session.delete(event)
        db.session.delete(schedule)
        db.session.commit()
        return jsonify({'status': 'success', 'message': 'Schedule deleted successfully'})
    
    # Update schedule
    data = request.get_json()
    schedule.frequency = data['frequency']
    schedule.days = ','.join(data.get('days', []))
    schedule.start_date = datetime.fromisoformat(data['startDate'])
    schedule.time_start = datetime.strptime(data['timeStart'], '%H:%M').time()
    schedule.time_end = datetime.strptime(data['timeEnd'], '%H:%M').time()
    
    if 'endDate' in data:
        schedule.end_date = datetime.fromisoformat(data['endDate'])
    
    # Delete old events
    for event in events:
        db.session.delete(event)
    
    # Create new events
    new_events = []
    current_date = schedule.start_date
    end_date = schedule.end_date or (current_date + timedelta(days=365))
    
    while current_date <= end_date:
        if schedule.frequency == 'daily' or (
            schedule.frequency == 'weekly' and 
            current_date.strftime('%a').upper() in schedule.days.split(',')
        ):
            event = Event(
                title=data['title'],
                start=datetime.combine(current_date.date(), schedule.time_start),
                end=datetime.combine(current_date.date(), schedule.time_end),
                description=data.get('description', ''),
                location=data.get('location', ''),
                color=data.get('color', '#3788d8'),
                is_recurring=True,
                schedule=schedule,
                user_id=current_user.id
            )
            new_events.append(event)
        
        current_date += timedelta(days=1)
    
    db.session.add_all(new_events)
    db.session.commit()
    
    return jsonify({
        'status': 'success',
        'message': 'Schedule updated successfully'
    })

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5001)
