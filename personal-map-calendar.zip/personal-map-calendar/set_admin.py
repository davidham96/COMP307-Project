from app import app, db, User

def set_admin(email):
    with app.app_context():
        user = User.query.filter_by(email=email).first()
        if not user:
            print(f"No user found with email: {email}")
            return
        
        user.is_admin = True
        db.session.commit()
        print(f"Successfully set {email} as admin")

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Usage: python set_admin.py <email>")
        sys.exit(1)
    
    email = sys.argv[1]
    set_admin(email)
